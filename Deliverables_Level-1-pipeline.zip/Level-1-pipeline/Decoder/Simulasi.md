![image](https://github.com/user-attachments/assets/cec4e9f2-7a76-4c48-98f2-a3a0b7390491)
Dari input menuju output membutuhkan 2 clock cycle





![spongebob](https://github.com/user-attachments/assets/fea2b741-ddf8-4e23-a78e-4fb032cd27f1)

Beritahukan saya kalau ada yang perlu diperbaiki
