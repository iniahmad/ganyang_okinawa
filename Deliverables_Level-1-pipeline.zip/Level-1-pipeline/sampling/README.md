Baru bikin versi 1

Versi 1 (Sekarang pakai yang ini)
![image](https://github.com/user-attachments/assets/d87682ec-c9fc-4df3-abbc-7fab45cab0ec)


Versi 2
![image](https://github.com/user-attachments/assets/cb648977-c20a-44b2-a3d1-de80127cc322)
